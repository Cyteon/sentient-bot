# Sentient
> Kinda scuffed bot rn

## Run Locally

1. Clone the project

```bash
  git clone https://github.com/Cyteon/sentient-bot
```

2. Go to the project directory

```bash
  cd sentient-bot
```

3. Install python dependencies

```bash
  pip install -r requirements.txt
```

4. Rename `.env.example` to `.env`, and populate the required values
5. Rename `config.examaple.json` to `config.json` and populate the required values

6. Run the bot

```bash
  python main.py
```
